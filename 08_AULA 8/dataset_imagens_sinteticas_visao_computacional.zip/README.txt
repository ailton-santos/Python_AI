Dataset sintético para aula de visão computacional.

Estrutura:
dataset/
  normal/
  defeito/

Cada imagem representa uma peça circular simples.
Classe 'normal': peça sem defeito visível.
Classe 'defeito': peça com trinca, mancha ou borda lascada.
