Dataset sintético variado de cães e gatos para visão computacional.

Estrutura:
dataset/
  gatos/
  caes/

Variações incluídas:
- cores de pelagem
- padrões de pelagem
- tamanho e formato do rosto
- cor do focinho/nariz
- quantidade de bigodes
- cor dos olhos
- formato da cabeça
- tipo de orelha
